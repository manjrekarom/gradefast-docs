def quicksort(x):
    return x

